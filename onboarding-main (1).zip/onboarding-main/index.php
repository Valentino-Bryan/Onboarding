<?php
// Redirect to the main application
header("Location: root/checklist.php");
exit;

